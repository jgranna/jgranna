
# map preps
library(mgcv)
library(maptools)
library(spdep)
library(BayesX)
library(colorspace)
library(tidyverse)
library(ggplot2)
library(rgeos)
library(sf)

# prepare data; cd into folder
load('./data/bay.rda')
gsf <- read_sf("./data/plz-3stellig/plz-3stellig.shp")
ger.map <- readShapePoly("./data/plz-3stellig/plz-3stellig.shp")
bay.map <- subset(ger.map, plz %in% bay)
bsf <- subset(gsf, plz %in% bay)
Bay <- list()
bay <- droplevels(bay)
bnd.bay <- read.bnd("./data/bay_plz3st.bnd")

# unique, so there are no repititions in the data
np <- unique(names(bnd.bay))
for(j in np) {
  tp <- subset(bay.map, plz == j)
  tp <- bnd.bay[which(names(bnd.bay) == j)]
  ## for-Schleife nur noetig, falls man doppelt vorkommende districts hat
  for(i in seq_along(tp))
    ## convert matrix into list of polygons
    tp[[i]] <- Polygon(tp[[i]])
  Bay[[j]] <- Polygons(tp, ID = j)
}
Bay <- SpatialPolygons(Bay)
cntrds <- gCentroid(Bay, byid = TRUE)

set.seed(3011)

# make cluster from each postcode
ncluster <- length(Bay)
ntime <- 100

n <- ncluster*ntime
id <- rep(1:ncluster, each=ntime)
time <- rep(1:ntime, ncluster)

dat <- data.frame(id, time)

dat$x <- runif(n, pi/2, 3*pi/2)
dat$fx <- sin(dat$x) # im Schnitt um 0 zentriert

dat$ftime <- cos((time-1)/100*2*pi)

dat$beta0i <- rep(rnorm(ncluster, 0, 0.7), each=ntime)
dat$beta0i <- dat$beta0i - mean(dat$beta0i)

dat$gamma0i <- rep(rnorm(ncluster, 0, 0.49), each=ntime)
dat$gamma0i <- dat$gamma0i - mean(dat$gamma0i)

# randomly drawn from [-pi, pi]
dat$z  <- rep(runif(ncluster, 1, 100), each = ntime)
dat$fz <- 0.7*cos((dat$z-1)/100*2*pi) 
dat$fz <- dat$fz - mean(dat$fz)

# generate spatial main effect
map <- st_read("./data/plz-3stellig/plz-3stellig.shp", stringsAsFactors = FALSE)
map <- subset(map, plz %in% bay)
map$centroids <- st_centroid(map$geometry)
effect <- data.frame(plz = names(Bay), mrf = sin(2 * cntrds@coords[,1] + cntrds@coords[,2]))
effect$mrf <- effect$mrf - mean(effect$mrf) # zur Zentrierung um 0
map <- merge(map, effect, by = "plz")

# randomly allocate plz and match effect from mrf
smp.plz <- sample(seq_along(effect$plz), ncluster, replace = FALSE)
dat$plz <- effect$plz[rep(smp.plz, each = ntime)]
dat <- inner_join(dat, effect, by = "plz")

# dat$eta <- dat$beta0i + dat$ftime + dat$fx*exp(dat$gamma0i + dat$fz) + dat$mrf
dat$eta <- dat$ftime + dat$fx*exp(dat$gamma0i + dat$fz) + dat$mrf
dat$y <- rnorm(n, dat$eta, sd(dat$eta) / 2) # orig 1, sd(eta) / {1, 2, 3}

dat2 <- dat
dat[, -which(names(dat) == "plz")] <- round(dat[, -which(names(dat) == "plz")], 3)

id <- data.frame(id=1:ncluster, z = unique(dat$z), plz = unique(dat$plz))

# save simulated data
setwd("./")
write.table(id, "simdata_id_sr2.raw", row.names=FALSE, col.names=TRUE, sep=" ", quote=FALSE)
write.table(dat, "simdata_sr2.raw", row.names=FALSE, col.names=TRUE, sep=" ", quote=FALSE)


