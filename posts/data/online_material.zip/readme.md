## Contents

-   data/ : contains the data needed for simulations and estimation
-   estimate : contains the estimation file for exp()-scaling
-   1_+_alpha.txt : contains the estimation file for (1+alpha)-scaling
